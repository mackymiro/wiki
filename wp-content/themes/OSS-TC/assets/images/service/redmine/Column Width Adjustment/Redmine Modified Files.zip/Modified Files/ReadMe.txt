_list.html.erb file directory
 - app/views/issues

production.rb file directory
 - config/environment

Paste width_adjust.js file to app/assets/javascripts folder
[Note: Manually create assets and javascripts folder if they don't exist]