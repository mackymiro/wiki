function contextMenuAddSelection(tr) {
  tr.addClass('context-menu-selection');
  contextMenuCheckSelectionBox(tr, true);
  contextMenuClearDocumentSelection();
  updateCount();
}

function contextMenuRemoveSelection(tr) {
  tr.removeClass('context-menu-selection');
  contextMenuCheckSelectionBox(tr, false);
  updateCount();
}


function toggleIssuesSelection(el) {
  var checked = $(this).prop('checked');
  var boxes = $(this).parents('table').find('input[name=ids\\[\\]]');
  boxes.prop('checked', checked).parents('tr').toggleClass('context-menu-selection', checked);
  updateCount();
}

function select_issue() {
        $('#issue-list-checkbox input[type=checkbox]').each(function () {
          $(this).change(updateCount);
        });

        updateCount();
}

function updateCount() {
  var count = $('#issue-list-checkbox input[type=checkbox]:checked').length;

  $('#count').text(count);
  $('#status').toggle(count >= 0);
}
