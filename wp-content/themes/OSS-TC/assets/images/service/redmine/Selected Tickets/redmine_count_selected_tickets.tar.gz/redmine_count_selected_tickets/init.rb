Redmine::Plugin.register :redmine_count_selected_tickets do
  name 'Redmine Count Selected Tickets plugin'
  author 'NSP GDCP'
  description 'This plugin counts selected tickets at issue list display'
  version '0.0.1'
end
