
# Color
red='\033[0;31m'
no_color='\033[0m' # No Color
green='\033[0;32m'

echo -e "\n\n\n\n Checking /app/views/layouts/base.html.erb"

# Check base.html.erb if exist at redmine directory
if [ -f ../app/views/layouts/base.html.erb ]; then
    echo "base.html.erb exist"
else
    echo "no base.html.erb"
	exit 1
fi

# check patch if exist
if [ -f base.html.erb.patch ]; then
    echo "base.html.erb.exist exist"
else
    echo "no base.html.erb.patch"
	exit 1
fi

echo "applying patch to base.html.erb.patch"
patch ../app/views/layouts/base.html.erb < base.html.erb.patch

# Check if patch successful
if [ $? -eq 0 ]; then
    echo -e "${green}SUCCESSFULLY ${no_color}apply patch"
else
    echo -e "${red}FAILED${no_color} to apply patch"
fi


