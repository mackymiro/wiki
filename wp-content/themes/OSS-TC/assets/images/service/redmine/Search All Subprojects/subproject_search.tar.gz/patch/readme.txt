Step by step instruction:
1.) run ./modify_patch.sh
2.) run ./run_patch.sh


NOTE: 
new-base.html.erb contains the modification.