# modify patch

# Color
red='\033[0;31m'
no_color='\033[0m' # No Color
green='\033[0;32m'

echo -e "Checking new-base.html.erb"

# Check base.html.erb if exist at redmine directory
if [ -f new-base.html.erb ]; then
    echo "new-base.html.erb exist"
else
    echo "no new-base.html.erb"
	exit 1
fi

# Check base.html.erb if exist at redmine directory
if [ -f base.html.erb.patch ]; then
    echo "base.html.erb.patch already exist"
	echo "deleting base.html.erb.patch"
	rm base.html.erb.patch
else
    echo "new-base.html.erb.patch not yet exist"
fi

echo "Creating patch"

# diff -u oldfile-name-here newfile-name-here > patch.diff
diff -u  new-base.html.erb ../app/views/layouts/base.html.erb > base.html.erb.patch

