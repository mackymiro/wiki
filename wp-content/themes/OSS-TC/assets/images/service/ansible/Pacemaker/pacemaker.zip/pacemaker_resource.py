#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2016, Nickson Ian Legaspi <legaspi.ni@ntsp.nec.co.jp>
#
# This module is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this software.  If not, see <http://www.gnu.org/licenses/>.

ANSIBLE_METADATA = {'metadata_version': '1.0',
                    'status': ['preview'],
                    'supported_by': 'curated'}


DOCUMENTATION = '''
---
module: pacemaker_resource
short_description: Manage cluster resource
version_added: "2.2"
author: "Nickson Ian Legaspi"
description:
    - This module can manage a pacemaker resources from Ansible using
      the pacemaker cli.
options:
    name:
        description:
          - Resource ID. When 'all' is specified it means all resource ID and this keyword can
            can be used when 'state' is 'started', 'stopped', 'absent' and 'oper' is 'cleanup'
            or 'status'.
        required: true
        default: none

    state:
        description:
          - The desired action to take on the resource.
            Valid values are the following.
            'present'   Resource is created and started.
            'absent'    Resource is deleted.
            'started'   Resource is manually started (enable).
            'stopped'   Resource is manually stopped (disable).
        required: false
        default: none
        choices: [ present, absent, started, stopped ]

    resource_type:
        description:
          - Resource type that specifies "standard" and "provider" info.
            '[standard:provider:type|type]' are the valid values.
            This is required when state is 'present'.
        required: false
        default: none

    oper:
        description:
          - An operation to perform.
            Valid values are the following.
            'cleanup'   Cleanups the resource.
            'status'    Retrieve the resource state.
        required: false
        default: none
        choices: [ cleanup, status ]

    args:
        description:
          - Resource arguments e.g. [resource options], [op <operation action> <operation options>],
              [metat <meta options>...], [--clone <clone options>], [--master <master options>],
              [--group <group id>], [--wait[=n]], [--node <node>] etc. of 'pcs resource' command.
        required: false
        default: none

    timeout:
        description:
          - The amount of time in seconds to wait to finish the operation of the resource.
        required: false
        default: 300
requirements:
    - "python >= 2.7"
'''

EXAMPLES = '''
---
- name: pacemaker resource
  hosts: localhost
  gather_facts: no
  tasks:
    - name: add a resource
      pacemaker_resource:
          name: VirtualIP
          resource_type: IPaddr2
          args: ip=192.168.50.200 cidr_netmask=32 op monitor interval=30s
          state: present

    - name: delete a resource
      pacemaker_resource:
          name: VirtualIP
          state: absent

    - name: manually start (enable) a resource
      pacemaker_resource:
          name: VirtualIP
          state: started

    - name: manually start (enable) all resource
      pacemaker_resource:
          name: all
          state: started

    - name: manually stop (disable) a resource
      pacemaker_resource:
          name: VirtualIP
          state: stopped

    - name: manually stop (disable) all resource
      pacemaker_resource:
          name: all
          state: stopped

    - name: perform cleanup of resource
      pacemaker_resource:
          name: VirtualIP
          oper: cleanup
          args: --node ansible-vm1

    - name: get status of a resource
      pacemaker_resource:
          name: VirtualIP
          oper: status

    - name: get status of all resource
      pacemaker_resource:
          name: all
          oper: status


'''

RETURN = '''
changed:
    description: True if the resource state has changed
    type: bool
    returned: always
out:
    description: Output the current state of the resource.
                 It may also return a list of the resource state.
    type: str
    sample:
             "out": "absent"
             "out": " ssh_svc        (systemd:sshd): Started ansible-vm2"
    returned: operation success
msg:
    description: The output message the operation of the resource failed.
    type: str
    sample: '"msg": "Failed to execute command: pcs resource delete VirtualIP.
                     Error: unable to find resource VirtualIP."'
    returned: operation failure
rc:
    description: exit code of the module
    type: int
    returned: always
'''

import time
import socket
import sys
from distutils.version import StrictVersion
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils import six

_PCS_DEF_STATUS_OFFLINE = "Offline"
_PCS_DEF_STATUS_ONLINE = "Online"
_PCS_DEF_STATUS_STARTED = "Started"
_PCS_DEF_STATUS_STOPPED = "Stopped"
_PCS_DEF_STATUS_FAILED = "FAILED"

_PCS_DEF_STATE_STARTED = "started"
_PCS_DEF_STATE_STOPPED = "stopped"
_PCS_DEF_STATE_PRESENT = "present"
_PCS_DEF_STATE_ABSENT = "absent"
_PCS_DEF_STATE_FAILED = "failed"
_PCS_DEF_STATE_UNKNOWN = "unknown"

_PCS_DEF_CLONE_SET = "Clone Set:"
_PCS_DEF_MASTER_SLAVE_SET = "Master/Slave Set:"
_PCS_DEF_RESOURCE_GROUP = "Resource Group:"
_PCS_DEF_MASTERS = "Masters:"
_PCS_DEF_SLAVES = "Slaves:"
_PCS_DEF_STARTED = "Started:"
_PCS_DEF_STOPPED = "Stopped:"
_PCS_DEF_FAILED = "FAILED:"
_PCS_DEF_STOPPED_DISABLED = "Stopped (disabled)"
_PCS_DEF_ALL = "ALL"

_PCS_DEF_OPER_STATUS = "status"
_PCS_DEF_OPER_CLEANUP = "cleanup"


def get_hostname():
    return socket.gethostname()


def get_cluster_status(module):
    cmd = "pcs cluster status"
    rc, out, err = module.run_command(cmd)
    if rc != 0:
        msg = "Failed to execute command: `{0}`.\n {1}".format(cmd, err)
        return _PCS_DEF_STATUS_OFFLINE, rc, msg
    else:
        return _PCS_DEF_STATUS_ONLINE, rc, out


def get_resource_state(module, name):
    clone_found = False
    cmd = "pcs resource show"
    rc, out, err = module.run_command(cmd)
    if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
    lines = out.splitlines()
    if name not in "all":
        for idx, detail in enumerate(lines):
            if (_PCS_DEF_CLONE_SET in detail) and (name in detail):
                count = 0
                index = idx
                while (count < 2):
                    try:
                        next_detail = lines[index + 1]
                    except IndexError as e:
                        break
                    if (next_detail.split()[0] in (_PCS_DEF_STARTED, _PCS_DEF_STOPPED, _PCS_DEF_FAILED)) or \
                            (_PCS_DEF_STOPPED_DISABLED in next_detail.split(':')[0]):
                        hostname = get_hostname()
                        if (_PCS_DEF_STARTED in next_detail) and (hostname in next_detail):
                            return _PCS_DEF_STATE_STARTED, next_detail
                        elif ((_PCS_DEF_STOPPED in next_detail) or (_PCS_DEF_STOPPED_DISABLED in next_detail)) and (hostname in next_detail):
                            return _PCS_DEF_STATE_STOPPED, next_detail
                        elif (_PCS_DEF_FAILED in next_detail) and (hostname in next_detail):
                            return _PCS_DEF_STATE_FAILED, next_detail
                        index += 1
                        count += 1
                    else:
                        break
                else:  # else part of the loop
                    return _PCS_DEF_STATE_UNKNOWN, next_detail
            elif (_PCS_DEF_MASTER_SLAVE_SET in detail) and (name in detail):
                count = 0
                index = idx
                while (count < 2):
                    try:
                        next_detail = lines[index + 1]
                    except IndexError as e:
                        break
                    if next_detail.split()[0] in (_PCS_DEF_MASTERS, _PCS_DEF_SLAVES, _PCS_DEF_STOPPED, _PCS_DEF_FAILED) or \
                            (_PCS_DEF_STOPPED_DISABLED in next_detail.split(':')[0]):
                        hostname = get_hostname()
                        if ((_PCS_DEF_MASTERS in next_detail) or (_PCS_DEF_SLAVES in next_detail)) and (hostname in next_detail):
                            return _PCS_DEF_STATE_STARTED, next_detail
                        elif ((_PCS_DEF_STOPPED in next_detail) or (_PCS_DEF_STOPPED_DISABLED in next_detail)) and (hostname in next_detail):
                            return _PCS_DEF_STATE_STOPPED, next_detail
                        elif (_PCS_DEF_FAILED in next_detail) and (hostname in next_detail):
                            return _PCS_DEF_STATE_FAILED, next_detail
                        index += 1
                        count += 1
                    else:
                        break
                else:  # else part of the loop
                    return _PCS_DEF_STATE_UNKNOWN, next_detail
            elif (_PCS_DEF_RESOURCE_GROUP in detail) and (name in detail):
                group = detail.split(":")
                if name in group[1]:
                    return _PCS_DEF_STATE_PRESENT, detail
                else:
                    return _PCS_DEF_STATE_ABSENT, None
            elif name in detail:
                if _PCS_DEF_STATUS_FAILED in detail:
                    return _PCS_DEF_STATE_FAILED, detail
                elif _PCS_DEF_STATUS_STARTED in detail:
                    return _PCS_DEF_STATE_STARTED, detail
                elif _PCS_DEF_STATUS_STOPPED in detail:
                    return _PCS_DEF_STATE_STOPPED, detail
                else:
                    return _PCS_DEF_STATE_UNKNOWN, detail
        else:  # else part of the loop
            return _PCS_DEF_STATE_ABSENT, None
    else:
        return _PCS_DEF_ALL, out


def get_all_resourcename(module):
    resource_list = []
    cmd = "pcs resource show"
    rc, out, err = module.run_command(cmd)
    if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
    lines = out.splitlines()
    for detail in lines:
        if (_PCS_DEF_CLONE_SET in detail) or (_PCS_DEF_MASTER_SLAVE_SET in detail):
            resource_names = detail.split(":")[1].replace("[", "").replace("]", "").split()
            for name in resource_names:
                resource_list.append(name)
        elif _PCS_DEF_RESOURCE_GROUP in detail:
            resource_list.append(detail.split(":")[1])
        elif detail.split()[0] in (_PCS_DEF_MASTERS, _PCS_DEF_SLAVES, _PCS_DEF_STARTED, _PCS_DEF_STOPPED, _PCS_DEF_FAILED) or \
                (_PCS_DEF_STOPPED_DISABLED in detail.split(':')[0]):
            continue
        else:
            if ":" in detail.split()[0]:
                resource_list.append(detail.split()[0].split(":")[0])
            else:
                resource_list.append(detail.split()[0])
    return resource_list


def create_resource(module, name, resource_type, args, state, timeout):
    if name == "all":
        module.fail_json(changed=False, msg="Resource name `{0}` is invalid.\n".format(name), rc=1)
    resource_state, detail = get_resource_state(module, name)
    if _PCS_DEF_STATE_ABSENT in resource_state:
        cmd = "pcs resource create"
        if resource_type is None:
            module.fail_json(changed=False, msg="Parameter 'resource_type' has no value.\n", rc=1)
        else:
            cmd = "{0} {1} {2}".format(cmd, name, resource_type)
        if args is not None:
            cmd = "{0} {1}".format(cmd, args)
        cmd = "{0} --wait={1}".format(cmd, timeout)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        resource_state, detail = get_resource_state(module, name)
        present = False
        if resource_state in (_PCS_DEF_STATE_STARTED, _PCS_DEF_STATE_STOPPED, _PCS_DEF_STATE_FAILED):
            present = True
        if not present:
            module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\n".format(name, state), rc=1)
        return True, resource_state, None
    else:
        return False, resource_state, detail


def delete_resource(module, name, state, timeout):
    if name not in "all":
        ret, resource_state, detail = delete_resource_single(module, name, state, timeout)
    else:
        ret, resource_state, detail = delete_resource_all(module, state, timeout)
    return ret, resource_state, detail


def delete_resource_single(module, name, state, timeout):
    resource_state, detail = get_resource_state(module, name)
    if state not in resource_state:
        cmd = "pcs resource delete"
        cmd = "{0} {1}".format(cmd, name)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)

        tm = time.time()
        deleted = False
        while time.time() < (tm + timeout):
            resource_state, detail = get_resource_state(module, name)
            if resource_state == state:
                deleted = True
                break
        if not deleted:
            module.fail_json(
                changed=False,
                msg="Timeout occurred after `{0}` second(s).\nFailed to set resource `{1}` state to `{2}`.\n".format(timeout, name, state),
                rc=1,
            )
        return True, resource_state, None
    else:
        return False, resource_state, None


def delete_resource_all(module, state, timeout):
    count = 0
    resource_list = []
    resource_list = get_all_resourcename(module)
    for resource in resource_list:
        ret, resource_state, detail = delete_resource_single(module, resource, state, timeout)
        if ret:
            count += 1
    if count > 0:
        return True, resource_state, None
    else:
        return False, resource_state, None


def enable_resource(module, name, state, timeout):
    if name not in "all":
        ret, resource_state, detail = enable_resource_single(module, name, state, timeout)
    else:
        ret, resource_state, detail = enable_resource_all(module, state, timeout)
    return ret, resource_state, detail


def enable_resource_single(module, name, state, timeout):
    resource_state, detail = get_resource_state(module, name)
    if _PCS_DEF_STATE_ABSENT in resource_state:
        module.fail_json(changed=False, msg="Resource `{0}` does not exist.\n".format(name), rc=1)
    elif _PCS_DEF_STATE_STOPPED in resource_state:
        cmd = "pcs resource enable"
        cmd = "{0} {1} --wait={2}".format(cmd, name, timeout)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            detail = cleanup_resource(module, name, None)
            rc, out, err = module.run_command(cmd)
            if rc != 0:
                module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        started = False
        resource_state, detail = get_resource_state(module, name)
        if resource_state == state:
            started = True
        if not started:
            module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\n".format(name, state), rc=rc)
        return True, resource_state, None
    elif resource_state in (_PCS_DEF_STATE_FAILED, _PCS_DEF_STATE_UNKNOWN):
        detail = cleanup_resource(module, name, None)
        cmd = "pcs resource enable"
        cmd = "{0} {1} --wait={2}".format(cmd, name, timeout)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        started = False
        resource_state, detail = get_resource_state(module, name)
        if resource_state == state:
            started = True
        if not started:
            module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\n".format(name, state), rc=1)
        return True, resource_state, None
    elif _PCS_DEF_STATE_STARTED in resource_state:
        return False, resource_state, None
    elif _PCS_DEF_STATE_PRESENT in resource_state:
        cmd = "pcs resource enable"
        cmd = "{0} {1}".format(cmd, name)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            detail = cleanup_resource(module, name, None)
            rc, out, err = module.run_command(cmd)
            if rc != 0:
                module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        return True, state, None
    else:
        return False, resource_state, detail


def enable_resource_all(module, state, timeout):
    count = 0
    resource_list = []
    resource_list = get_all_resourcename(module)
    for resource in resource_list:
        ret, resource_state, detail = enable_resource_single(module, resource, state, timeout)
        if ret:
            count += 1
    if count > 1:
        return True, resource_state, None
    else:
        return False, resource_state, detail


def disable_resource(module, name, state, timeout):
    if name not in "all":
        ret, resource_state, detail = disable_resource_single(module, name, state, timeout)
    else:
        ret, resource_state, detail = disable_resource_all(module, state, timeout)
    return ret, resource_state, detail


def disable_resource_single(module, name, state, timeout):
    resource_state, detail = get_resource_state(module, name)
    if _PCS_DEF_STATE_ABSENT in resource_state:
        module.fail_json(changed=False, msg="Resource `{0}` does not exist.\n".format(name), rc=1)
    elif _PCS_DEF_STATE_STARTED in resource_state:
        cmd = "pcs resource disable"
        cmd = "{0} {1} --wait={2}".format(cmd, name, timeout)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            detail = cleanup_resource(module, name, None)
            rc, out, err = module.run_command(cmd)
            if rc != 0:
                module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        stopped = False
        resource_state, detail = get_resource_state(module, name)
        if resource_state == state:
            stopped = True
        if not stopped:
            module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\n".format(name, state), rc=1)
        return True, resource_state, None
    elif resource_state in (_PCS_DEF_STATE_FAILED, _PCS_DEF_STATE_UNKNOWN):
        detail = cleanup_resource(module, name, None)
        cmd = "pcs resource disable"
        cmd = "{0} {1} --wait={2}".format(cmd, name, timeout)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)

        stopped = False
        resource_state, detail = get_resource_state(module, name)
        if resource_state == state:
            stopped = True
        if not stopped:
            module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\n".format(name, state), rc=1)
        return True, resource_state, None
    elif _PCS_DEF_STATE_PRESENT in resource_state:
        cmd = "pcs resource disable"
        cmd = "{0} {1}".format(cmd, name)
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            detail = cleanup_resource(module, name, None)
            rc, out, err = module.run_command(cmd)
            if rc != 0:
                module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
        return True, state, None
    else:
        return False, resource_state, detail


def disable_resource_all(module, state, timeout):
    count = 0
    resource_list = []
    resource_list = get_all_resourcename(module)
    for resource in resource_list:
        ret, resource_state, detail = disable_resource_single(module, resource, state, timeout)
        if ret:
            count += 1
    if count > 1:
        return True, resource_state, None
    else:
        return False, resource_state, detail


def cleanup_resource(module, name, args):
    cmd = "pcs resource cleanup"
    if name not in "all":
        cmd = "{0} {1}".format(cmd, name)
    if args is not None:
        cmd = "{0} {1}".format(cmd, args)
    rc, out, err = module.run_command(cmd)
    if rc != 0:
        module.fail_json(changed=False, msg="Failed to execute command: `{0}`.\n {1}".format(cmd, err), rc=rc)
    return out


def main():
    argument_spec = dict(
        name=dict(required=True),
        state=dict(choices=['present', 'absent', 'started', 'stopped']),
        resource_type=dict(required=False),
        oper=dict(choices=['cleanup', 'status']),
        resource_args=dict(required=False),
        args=dict(required=False),
        timeout=dict(default=300, type='int'))

    module = AnsibleModule(argument_spec,
                           supports_check_mode=True)

    changed = False
    # Check if cluster is started
    cluster_state, retcode, detail = get_cluster_status(module)
    if cluster_state == _PCS_DEF_STATUS_OFFLINE:
        module.fail_json(changed=changed, msg=detail, rc=retcode)

    name = module.params['name']
    state = module.params['state']
    resource_type = module.params['resource_type']
    oper = module.params['oper']
    args = module.params['args']
    timeout = module.params['timeout']

    if name is None:
        module.fail_json(changed=False, msg="Resource name `{0}` is invalid.\n".format(name), rc=1)
    if (state is not None) and (oper is not None):
        module.fail_json(changed=False, msg="Cannot specify parameter state `{0}` and oper `{1}` at the same time.\n".format(state, oper), rc=1)
    elif state is not None:
        if _PCS_DEF_STATE_PRESENT in state:
            exec_res, rsc_state, detail = create_resource(module, name, resource_type, args, state, timeout)
            if exec_res:
                module.exit_json(changed=exec_res, out=rsc_state, rc=0)
            elif not exec_res and (rsc_state in (_PCS_DEF_STATE_STARTED, _PCS_DEF_STATE_STOPPED, _PCS_DEF_STATE_FAILED)):
                module.exit_json(changed=exec_res, out=state, rc=0)
            else:
                module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\nOperation result: {2}'".format(name, state, detail), rc=1)
        elif _PCS_DEF_STATE_ABSENT in state:
            exec_res, rsc_state, detail = delete_resource(module, name, state, timeout)
            if exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=rsc_state, rc=0)
            elif not exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=state, rc=0)
            else:
                module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\nOperation result: {2}".format(name, state, detail), rc=1)
        elif _PCS_DEF_STATE_STARTED in state:
            exec_res, rsc_state, detail = enable_resource(module, name, state, timeout)
            if exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=rsc_state, rc=0)
            elif not exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=state, rc=0)
            else:
                module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\nOperation result: {2}".format(name, state, detail), rc=1)
        elif _PCS_DEF_STATE_STOPPED in state:
            exec_res, rsc_state, detail = disable_resource(module, name, state, timeout)
            if exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=rsc_state, rc=0)
            elif not exec_res and (rsc_state == state):
                module.exit_json(changed=exec_res, out=state, rc=0)
            else:
                module.fail_json(changed=False, msg="Failed to set resource `{0}` state to `{1}`.\nOperation result: : {2}".format(name, state, detail), rc=1)
        else:
            module.fail_json(changed=False, msg="Invalid parameter value of state `{0}`.\n".format(state), rc=1)
    elif oper is not None:
        if _PCS_DEF_OPER_STATUS in oper:
            rsc_state, detail = get_resource_state(module, name)
            if _PCS_DEF_STATE_ABSENT in rsc_state:
                module.exit_json(changed=False, out=rsc_state, rc=0)
            else:
                module.exit_json(changed=False, out=detail, rc=0)
        elif _PCS_DEF_OPER_CLEANUP in oper:
            detail = cleanup_resource(module, name, args)
            module.exit_json(changed=True, out=detail, rc=0)
        else:
            module.fail_json(changed=False, msg="Invalid parameter value of oper `{0}`.\n".format(oper), rc=1)
    else:
        module.fail_json(changed=False, msg="Invalid parameter value of state `{0}` or oper `{1}`.\n".format(state, oper), rc=1)


if __name__ == '__main__':
    main()
