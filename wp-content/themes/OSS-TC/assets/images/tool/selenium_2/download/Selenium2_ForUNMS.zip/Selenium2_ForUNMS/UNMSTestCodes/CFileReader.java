/*****************************************************************************
 * Copyright 2017 NEC Telecom Software Phils., Inc.
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  
 ****************************************************************************/

package testPackage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CFileReader {
	
	/* The name of the file which contains UNMS Client information login details */
	String strFileName_Conf = null;
	
	/* The name of the file for registration */
    String strFileName_Reg = null;

    /* The name of the file for deletion */
    String strFileName_Del = null;
    
    /* This will reference one line at a time */
      List<String> sDelPath_L1 = new ArrayList<String>();
      List<String> sDelPath_L2 = new ArrayList<String>();
    
    /**
     * 
     */
    public CFileReader() {
    	
    	this.strFileName_Reg = "D://01_PROJECT//11_OSS_Tech_Center//05_Workspaces//SeleniumTestProject//src//testPackage//PathReg.json";
    	this.strFileName_Del = "D://01_PROJECT//11_OSS_Tech_Center//05_Workspaces//SeleniumTestProject//src//testPackage//PathDel.json";
    	this.strFileName_Conf = "D://01_PROJECT//11_OSS_Tech_Center//05_Workspaces//SeleniumTestProject//src//testPackage//UNMSConfig.json";

    }
    
    /**
     * 
     * @param sFile
     * @return
     */
    public CUnmsConf readConfFile(String sFile) {
    	
    	CUnmsConf oUnms = new CUnmsConf();
    	
    	if(null != sFile) {
    		this.strFileName_Conf = sFile;
    	}
    	
    	JSONParser parser = new JSONParser();
    	
    	try {
    		JSONObject jsonObj = (JSONObject) parser.parse(new FileReader(this.strFileName_Conf));
    		
    		oUnms.setStrWebDriver((String) jsonObj.get("Selenium WebDriver"));
    		oUnms.setStrIpAdd((String) jsonObj.get("UNMS IP Address"));
    		oUnms.setStrUser((String) jsonObj.get("Username"));
    		oUnms.setStrPass((String) jsonObj.get("Password"));
    		
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    	
    	return oUnms;
    }
    
    /**
     * 
     * @param sFile
     * @return
     */
    public List<CPathInfo> readFileForReg(String sFile) {
    	
    	List<CPathInfo> listPathData = new ArrayList<CPathInfo>();
    	
    	if(null != sFile) {
    		this.strFileName_Reg = sFile;
    	}
    	
    	JSONParser parser = new JSONParser();
  		 
        try {
 
        	JSONArray regArr = (JSONArray) parser.parse(new FileReader(this.strFileName_Reg));
        	
        	for(Object obj : regArr) {
        		
        		CPathInfo oPath = new CPathInfo();
        		
        		JSONObject jsonObject = (JSONObject) obj;
        		
        		oPath.setStrPathMgmt((String) jsonObject.get("L1/L2"));
        		oPath.setStrPathType((String) jsonObject.get("Path Type"));
        		oPath.setStrPathName((String) jsonObject.get("Path Name"));
        		oPath.setStrVLANName((String) jsonObject.get("VLAN Name"));
        		oPath.setStrVLANID((String) jsonObject.get("VLAN ID"));
        		oPath.setStrSvcType((String) jsonObject.get("Service Type"));	        		
        		
        		/* Retrieve A-NE */
        		CNEInfo oANE = new CNEInfo();
        		JSONObject tempNE = (JSONObject) jsonObject.get("A-NE");
        		
        		oANE.setStrName((String) tempNE.get("NE Name"));
        		oANE.setStrCardSlot((String) tempNE.get("A-End Card/Slot"));
        		oANE.setStrPort((String) tempNE.get("A-End Port"));
        		oANE.setStrVLANPortType((String) tempNE.get("A-End VLAN Port Type"));
        		oANE.setStrChNumber((String) tempNE.get("A-End Channel"));
        		oPath.setObjEndNE_A(oANE);
        		
        		/* Retrieve list of Middle NEs */
        		List<String> midNEs = new ArrayList<String>();
        		
                JSONArray arrNEs = (JSONArray) jsonObject.get("Mid-NE");
                
                for(Object tempMid : arrNEs) {
                	
                	JSONObject midObj = (JSONObject) tempMid;
                	
                	midNEs.add((String) midObj.get("Name"));
                	
                }
                oPath.setlStrMidNE(midNEs);
        		
        		/* Retrieve list of Section data */
        		List<CSectionInfo> lSectInfo = new ArrayList<CSectionInfo>();
        		JSONArray secArray = (JSONArray) jsonObject.get("Section");
        		
        		for (Object tempSec : secArray) {
        			CSectionInfo oSect = new CSectionInfo();
        			JSONObject secObj = (JSONObject) tempSec;
        			
        			oSect.setStrName((String) secObj.get("Section Name"));
        			
        			oSect.setStrCardSlot_A((String) secObj.get("Section ACard/Slot"));
        			oSect.setStrPort_A((String) secObj.get("Section APort"));
        			oSect.setStrChannel_A((String) secObj.get("Section AChannel"));
        			oSect.setStrPortName_A((String) secObj.get("Section APort Name"));
        			
        			oSect.setStrCardSlot_B((String) secObj.get("Section BCard/Slot"));
        			oSect.setStrPort_B((String) secObj.get("Section BPort"));
        			oSect.setStrChannel_B((String) secObj.get("Section BChannel"));
        			oSect.setStrPortName_B((String) secObj.get("Section BPort Name"));
        			
        			lSectInfo.add(oSect);
        		}
        		oPath.setlObjSection(lSectInfo);
        		
        		/* Retrieve Z-NE */
        		CNEInfo oZNE = new CNEInfo();
        		JSONObject tempZNE = (JSONObject) jsonObject.get("Z-NE");
        		
        		oZNE.setStrName((String) tempZNE.get("NE Name"));
        		oZNE.setStrCardSlot((String) tempZNE.get("Z-End Card/Slot"));
        		oZNE.setStrPort((String) tempZNE.get("Z-End Port"));
        		oZNE.setStrVLANPortType((String) tempZNE.get("Z-End VLAN Port Type"));
        		oZNE.setStrChNumber((String) tempZNE.get("Z-End Channel"));
        		oPath.setObjEndNE_Z(oZNE);
        		
        		listPathData.add(oPath);
        		
        	}
 
        } catch (Exception e) {
            e.printStackTrace();
        }
	        
    	return listPathData;
    }
    
    /**
     * 
     * @param sFile
     * @return
     */
    public void readFileForDelete(String sFile) {
    	
    	if(null != sFile) {
    		this.strFileName_Del = sFile;
    	}
    	
    	JSONParser parser = new JSONParser();
  		 
        try {
 
        	JSONArray delArr = (JSONArray) parser.parse(new FileReader(this.strFileName_Del));
        	
        	for(Object obj : delArr) {
        		
        		JSONObject jsonObject = (JSONObject) obj;
        		
        		String strPath = (String) jsonObject.get("L1/L2");
        		
        		JSONArray delArr_L1 = (JSONArray) jsonObject.get("Path List");
    			
        		if(strPath.equals("L1")) {
        			
        			for (Object objL1 : delArr_L1) {
        				
        				JSONObject delObj = (JSONObject) objL1;
        				
        				sDelPath_L1.add((String) delObj.get("Path Name"));
        			}
        			
        		} 
        		else if (strPath.equals("L2")) {
        			
        			for (Object objL1 : delArr_L1) {
        				
        				JSONObject delObj = (JSONObject) objL1;
        				
        				sDelPath_L2.add((String) delObj.get("Path Name"));
        			}
        		}
        		else {
        			System.out.println(" Unknown Path Management (L1 or L2)");
        		}
        		
        	}
 
        } catch (Exception e) {
            e.printStackTrace();
        }
	        
    }
    
    /**
     * 
     * @return
     */
    public List<String> getPathForDel_L1() {
    	
    		return sDelPath_L1;
    }
    
    /**
     * 
     * @return
     */
    public List<String> getPathForDel_L2() {
    	
		return sDelPath_L2;
    }
    
}
