/*****************************************************************************
 * Copyright 2017 NEC Telecom Software Phils., Inc.
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  
 ****************************************************************************/

package testPackage;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UNMSTestClass {
	
	List<WebElement> webElement;
		
	public UNMSTestClass() {
		webElement = null;
	}

	/**
	 * 
	 */
	public void ieCall() {
		
		System.out.println("UNMS Test Class is starting....");
		
		/* Read Config File */
		CFileReader oFileReader = new CFileReader();
		CUnmsConf unmsconf = new CUnmsConf();
		
		/* Set path of IEDriverServer.exe */
		unmsconf = oFileReader.readConfFile(null);
		System.setProperty("webdriver.ie.driver", unmsconf.getStrWebDriver());

		/* Initialize InternetExplorerDriver Instance */
		DesiredCapabilities returnCapabilities = DesiredCapabilities.internetExplorer();
		returnCapabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
		returnCapabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		WebDriver driver = new InternetExplorerDriver(returnCapabilities);

		/* Maximize Browser */
		driver.manage().window().maximize();
		
		/* Log-in */
		login(driver, unmsconf);
		
		/* WebDriver wait */
		WebDriverWait wait = new WebDriverWait(driver, 10000);
		WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("editmap-button")));
		
   		try {
//   			/* Get Data for Registration */
//   			List<CPathInfo> oPathInfoList = oFileReader.readFileForReg(null);
//			
//   			/* Register Path */
//   			registerPath(driver, wait, oPathInfoList);
   			
   			/* Delete Path -- L1 */
   			oFileReader.readFileForDelete("D://01_PROJECT//11_OSS_Tech_Center//05_Workspaces//SeleniumTestProject//src//testPackage//PathDel_L1.json");
   			
   			List<String> strDel_L1 = oFileReader.getPathForDel_L1();
   			deletePath(driver, wait, strDel_L1, "L1");
   			
   			/* Delete Path -- L2 */
//   			List<String> strDel_L2 = oFileReader.getPathForDel_L2();
//   			deletePath(driver, wait, strDel_L2, "L2");
   			
    	}
    	catch (NoSuchElementException e) {
    		System.out.println("No element found.");
    	}
    	catch (StaleElementReferenceException e) {
    		System.out.println("Element is not attached to the page document.");
    	}
    	catch (UnhandledAlertException e) {
    		System.out.println("Unexpected dialog box appears.");
    		
    		try {
    	        Alert alert = driver.switchTo().alert();
    	        String alertText = alert.getText();
    	        System.out.println("Alert data: " + alertText);
    	        alert.dismiss();
    	    } catch (NoAlertPresentException aE) {
    	    	aE.printStackTrace();
    	    }
    	}
    	catch(Exception e) {}
	}

	/**
	 * 
	 * @param driver
	 */
	public void login(WebDriver driver, CUnmsConf conf) {
		
		driver.get(conf.getStrIpAdd());
		driver.findElement(By.id("txtUserName")).sendKeys(conf.getStrUser()); 
		driver.findElement(By.id("txtPassword")).sendKeys(conf.getStrPass());
		driver.findElement(By.id("btnLogin")).click();
	}
	
	
	/**
	 * 
	 * @param driver
	 * @param wait
	 * @param oPathInfoList
	 */
	public void registerPath(WebDriver driver, WebDriverWait wait, List<CPathInfo> oPathInfoList) {
		
		System.out.println("Register uNMS Path Procedure STARTS.....");
		
		if(null != oPathInfoList) {
			if(!oPathInfoList.isEmpty()) {
				for (CPathInfo oPath : oPathInfoList) {
					
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("editmap-button")));
					
					System.out.println("pathinfolist loop....");
					
					// Click Edit Button
					WebElement editBtn = driver.findElement(By.id("editmap-button"));
					WebElement clickEditBtn = wait.until(ExpectedConditions.visibilityOf(editBtn));

					Actions action1 = new Actions(driver);
					action1.moveToElement(clickEditBtn);
					action1.click(clickEditBtn).build().perform();

					/* Select L1 or L2 */
					if(oPath.getStrPathMgmt().equals("L2")) {
					
						// Click L2 Path Button
						WebElement l2Btn = driver.findElement(By.id("editbutton-l2path"));
						WebElement clickl2Btn = wait.until(ExpectedConditions.visibilityOf(l2Btn));

						Actions action2 = new Actions(driver);
						action2.moveToElement(clickl2Btn);
						action2.click(clickl2Btn).build().perform();
						
						/* Select Path Type */
						WebElement pathtypebtn = null;
						WebElement clickpathtype = null;
						
						if(oPath.getStrPathType().equals("802.1Q")) {
							// Click L2 Path 8021q Button
							pathtypebtn = driver.findElement(By.id("editbutton-l2path-8021q"));
							clickpathtype = wait.until(ExpectedConditions.visibilityOf(pathtypebtn));
							Actions action3 = new Actions(driver);
							action3.moveToElement(clickpathtype);
							action3.click(clickpathtype).build().perform();

						} else if (oPath.getStrPathType().equals("802.1ad")) {
							// Click L2 Path 8021ad Button
							pathtypebtn = driver.findElement(By.id("editbutton-l2path-8021ad"));
							clickpathtype = wait.until(ExpectedConditions.visibilityOf(pathtypebtn));
							Actions action3 = new Actions(driver);
							action3.moveToElement(clickpathtype);
							action3.click(clickpathtype).build().perform();
						
						} else {
							System.out.println("Unknown Path Type");
						}
						
					}
					else if (oPath.getStrPathMgmt().equals("L1")) {
						// Click L1 Path Button
						WebElement l1Btn = driver.findElement(By.id("editbutton-l1path"));
						WebElement clickl1Btn = wait.until(ExpectedConditions.visibilityOf(l1Btn));

						Actions action2 = new Actions(driver);
						action2.moveToElement(clickl1Btn);
						action2.click(clickl1Btn).build().perform();
					}
					else {
						System.out.println("Unsupported Path Management");
					}
			
					System.out.println("Path Type = " + oPath.getStrPathType());
					
					/* click button according to Path Type -- end */
					
		   			/* Create Path */
					createPath(driver, wait, oPath);
				}
			}
		}
		
		System.out.println("Register L2 Path Procedure ENDS.....");
	}

	/**
	 * 
	 * @param driver
	 * @param wait
	 * @param oPath
	 */
	public void createPath(WebDriver driver, WebDriverWait wait, CPathInfo oPath) {
		
		boolean bSingle = true;
		String str_ANE_id = "";
		String str_ZNE_id = "";
		String strNEID = "";
		List<String> lMidNEIDs = new ArrayList<String>();
		
		System.out.println("CreatePath method STARTS.....");
		
		if(null != oPath) {
			
			bSingle = oPath.getlStrMidNE().isEmpty();
			System.out.println("Single? = " + bSingle);
			
			/* Retrieve NE ID for all NEs */
			str_ANE_id = retrieveNEID(driver, oPath.getObjEndNE_A().getStrName());
			str_ZNE_id = retrieveNEID(driver, oPath.getObjEndNE_Z().getStrName());
			
			if(!bSingle) {
				
				for (String strMidNE : oPath.getlStrMidNE()) {
					
					strNEID = "";
					strNEID = retrieveNEID(driver, strMidNE);
					
					lMidNEIDs.add(strNEID);
				}
			}
			
			String strTempNE = "Middle NEs : ";
			for (String temp : lMidNEIDs) {
				strTempNE += temp;
			}
			System.out.println(strTempNE);
			
			/* Create Drag IDs */ 
			List<String> lStr_drag = constructDragIDList(str_ANE_id, str_ZNE_id, lMidNEIDs);
			
			/* Click A-Node */
			WebElement aNode = driver.findElement(By.id(str_ANE_id));
			WebElement clickANode = wait.until(ExpectedConditions.visibilityOf(aNode));

			Actions act_ANode = new Actions(driver);
			act_ANode.moveToElement(clickANode);
			act_ANode.click(clickANode).build().perform();

			if(!bSingle) {
				
				for (String strNeId : lMidNEIDs) {
					
					/* Click Middle Node */
					WebElement midNode = driver.findElement(By.id(strNeId));
					WebElement clickMidNode = wait.until(ExpectedConditions.visibilityOf(midNode));
					Actions act_clickMidNode = new Actions(driver);
					act_clickMidNode.moveToElement(clickMidNode);
					act_clickMidNode.click(clickMidNode).build().perform();
					
					/* Click Middle Node Again */
					Actions act_clickMidNode2 = new Actions(driver);
					act_clickMidNode2.moveToElement(clickMidNode);
					act_clickMidNode2.click(clickMidNode).build().perform();
				}
			}
			System.out.println("After clicking middle nodes... ");

			
			/* Click Z-Node */
			WebElement zNode = driver.findElement(By.id(str_ZNE_id));
			WebElement clickZNode = wait.until(ExpectedConditions.visibilityOf(zNode));
			Actions act_zNode = new Actions(driver);
			act_zNode.moveToElement(clickZNode);
			act_zNode.click(clickZNode).build().perform();
			
			/* Click the line/path of the selected node */
			WebElement path = driver.findElement(By.id(lStr_drag.get(0)));			
			WebElement clickPath = wait.until(ExpectedConditions.visibilityOf(path));
			Actions act_path = new Actions(driver);
			act_path.moveToElement(clickPath);
			act_path.contextClick(clickPath).build().perform();

			/* Create Path */
			WebElement create = driver.findElement(By.linkText("Create Path"));
			WebElement clickCreate = wait.until(ExpectedConditions.visibilityOf(create));
			Actions act_create = new Actions(driver);
			act_create.moveToElement(clickCreate);
			act_create.click(clickCreate).build().perform();

			/* Scroll Down to show the web controls */
			JavascriptExecutor js1 = (JavascriptExecutor) driver;
			js1.executeScript("scroll(0, 250);");
			js1.executeScript("setTimeout(10);");

			System.out.println("Input Path Information....");
			
			if (oPath.getStrPathMgmt().equals("L2")) {
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtPathName")));
				
				/* Input Path Name */
				driver.findElement(By.id("txtPathName")).clear();
				driver.findElement(By.id("txtPathName")).sendKeys(oPath.getStrPathName());
				
				/* Input VLAN Name */
				driver.findElement(By.id("txtVlanName")).clear();
				driver.findElement(By.id("txtVlanName")).sendKeys(oPath.getStrVLANName());
	
				/* Input VlanId */
				driver.findElement(By.id("txtVlanId")).sendKeys(oPath.getStrVLANID());
				
				/* Input Service Type */
				WebElement svctype = driver.findElement(By.id("txtServiceType"));
				Select svctypedown= new Select(svctype); 
	
				if(!(svctypedown.getFirstSelectedOption().getText().equals(oPath.getStrSvcType()))) {
					svctype.sendKeys(oPath.getStrSvcType());
				}
				
				/* Extra processing for Section Registration -- START */
				
				/* Click A-End */
				WebElement aNode2 = driver.findElement(By.id(str_ANE_id));
				WebElement clickANode2 = wait.until(ExpectedConditions.visibilityOf(aNode2));
	
				Actions act_ANode2 = new Actions(driver);
				act_ANode2.moveToElement(clickANode2);
				act_ANode2.click(clickANode2).build().perform();
				
				/* Set values for A-End Card/Slot */ 
				WebElement aEndCardSlot = driver.findElement(By.id("1_cardSlotId"));
				Select aEndCardSlotDrpdwn= new Select(aEndCardSlot); 
	
				String str_aEndCardSlot = oPath.getObjEndNE_A().getStrCardSlot();
				if(!(aEndCardSlotDrpdwn.getFirstSelectedOption().getText().equals(str_aEndCardSlot))) {
					aEndCardSlot.sendKeys(str_aEndCardSlot);
				}
				
				/* Set values for A-End Port */
				WebElement aEndPort = driver.findElement(By.id("1_portNo"));
				Select aEndDropdown= new Select(aEndPort); 
	
				String str_aPort = oPath.getObjEndNE_A().getStrPort();
				if(!(aEndDropdown.getFirstSelectedOption().getText().equals(str_aPort))) {
					aEndPort.sendKeys(str_aPort);
				}
				
				/* Set values for A-End VLAN Port Type */ 
				WebElement aEndVLNPortType = driver.findElement(By.id("1_vlanPortType"));
				Select aEndVLNPortTypeDrpDwn = new Select(aEndVLNPortType); 
	
				String str_aVLNPortType = oPath.getObjEndNE_A().getStrVLANPortType();
				if(!(aEndVLNPortTypeDrpDwn.getFirstSelectedOption().getText().equals(str_aVLNPortType))) {
					aEndVLNPortType.sendKeys(str_aVLNPortType);
				}
			}
			else {  //L1 Path
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name("path_name_text-1")));
				
				/* Input Path Name */
				driver.findElement(By.name("path_name_text-1")).clear();
				driver.findElement(By.name("path_name_text-1")).sendKeys(oPath.getStrPathName());
				
				/* Input A-End Card/Slot */
				WebElement aEndCardSlot_L1 = driver.findElement(By.name("endpoint_a_slot-1"));
				Select aEndCardSlotDrpdwn_L1= new Select(aEndCardSlot_L1); 
	
				String str_aEndCardSlot_L1 = oPath.getObjEndNE_A().getStrCardSlot();
				if(!(aEndCardSlotDrpdwn_L1.getFirstSelectedOption().getText().equals(str_aEndCardSlot_L1))) {
					aEndCardSlot_L1.sendKeys(str_aEndCardSlot_L1);
				}
				
				/* Set values for A-End Port */
				WebElement aEndPort_L1 = driver.findElement(By.name("endpoint_a_port-1"));
				Select aEndDropdown_L1 = new Select(aEndPort_L1); 
	
				String str_aPort_L1 = oPath.getObjEndNE_A().getStrPort();
				if(!(aEndDropdown_L1.getFirstSelectedOption().getText().equals(str_aPort_L1))) {
					aEndPort_L1.sendKeys(str_aPort_L1);
				}
				
				/* Set values for A-End Channel */
				WebElement aEndCh_L1 = driver.findElement(By.name("endpoint_a_ch-1"));
				Select aEndChDrpdwn_L1 = new Select(aEndCh_L1); 
	
				String str_aCh_L1 = oPath.getObjEndNE_A().getStrChNumber();
				if(!(aEndChDrpdwn_L1.getFirstSelectedOption().getText().equals(str_aCh_L1))) {
					aEndCh_L1.sendKeys(str_aCh_L1);
				}
				
				/* Set values for Z-End Card/Slot */
				WebElement zEndCardSlot_L1 = driver.findElement(By.name("endpoint_z_slot-1"));
				Select zEndCardSlotDrpdwn_L1= new Select(zEndCardSlot_L1); 
				String strZCardSlot_L1 = oPath.getObjEndNE_Z().getStrCardSlot(); 
				if(!(zEndCardSlotDrpdwn_L1.getFirstSelectedOption().getText().equals(strZCardSlot_L1))) {
					zEndCardSlot_L1.sendKeys(strZCardSlot_L1);
				}
				
				/* Set values for Z-End Port */
				WebElement zEndPort_L1 = driver.findElement(By.name("endpoint_z_port-1"));
				Select zEndPortDrpdwn_L1 = new Select(zEndPort_L1);
				
				String strZPort_L1 = oPath.getObjEndNE_Z().getStrPort();
				if(!(zEndPortDrpdwn_L1.getFirstSelectedOption().getText().equals(strZPort_L1))) {
					zEndPort_L1.sendKeys(strZPort_L1);
				}
				
				/* Set values for Z-End Channel */
				WebElement zEndCh_L1 = driver.findElement(By.name("endpoint_z_ch-1"));
				Select zEndChDrpDwn_L1= new Select(zEndCh_L1); 
				String strCh_L1 = oPath.getObjEndNE_Z().getStrChNumber();
				if(!(zEndChDrpDwn_L1.getFirstSelectedOption().getText().equals(strCh_L1))) {
					zEndCh_L1.sendKeys(strCh_L1);
				}
				
			}
			
			int idragCnt = 0;
			
			for (String strDrag : lStr_drag) {
				
				/* Click Drag element and set values for SectionA Port & SectionB Port */
				WebElement segment = driver.findElement(By.id(strDrag));
				WebElement clickSegment = wait.until(ExpectedConditions.visibilityOf(segment));
				
				Actions act_Segment = new Actions(driver);
				act_Segment.pause(Duration.ofSeconds(2));
				act_Segment.click(clickSegment).build().perform();
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("input_selectRow_1")));
				
				/* Set values for Section Name */
				WebElement sSectionName = driver.findElement(By.id("input_selectRow_1"));
				String strSection = oPath.getlObjSection().get(idragCnt).getStrName();
				if(!(sSectionName.getText().equals(strSection)))
				{
					sSectionName.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END), strSection);
				}
				
				/* Set values for Section ACard/Slot */
				WebElement secACardSlot = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[5]/select"));
				Select secACardSlotDrpdwn= new Select(secACardSlot); 
	
				String strACard = oPath.getlObjSection().get(idragCnt).getStrCardSlot_A();
				if(!(secACardSlotDrpdwn.getFirstSelectedOption().getText().equals(strACard))) {
					secACardSlot.sendKeys(strACard);
				}
				
				/* Set values for Section Aport */				
				WebElement sAport = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[6]/select"));
				Select sADropdown = new Select(sAport);
				
				String strAPort = oPath.getlObjSection().get(idragCnt).getStrPort_A();
				if(!(sADropdown.getFirstSelectedOption().getText().equals(strAPort))) {
					sAport.sendKeys(strAPort);
				}
				
				if(oPath.getStrPathMgmt().equals("L1")) {
					
					/* Set value for Section A Channel */
					WebElement sACh = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[7]/select"));
					Select sAChDrpdwn = new Select(sACh);
					
					String strACh = oPath.getlObjSection().get(idragCnt).getStrChannel_A();
					if(!(sAChDrpdwn.getFirstSelectedOption().getText().equals(strACh))) {
						sACh.sendKeys(strACh);
					}
					
					/* Set value for Section A Port Name */
					WebElement sPortName = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[8]/input"));
					sPortName.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END),oPath.getlObjSection().get(idragCnt).getStrPortName_A());
					
				}
				
				//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[9]/select")));
				
				/* Set values for Section BCard/SLot */
				WebElement secBCardSlot = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[9]/select"));
				Select secBCardSlotDrpdwn= new Select(secBCardSlot); 
	
				String strBCard = oPath.getlObjSection().get(idragCnt).getStrCardSlot_B();
				if(!(secBCardSlotDrpdwn.getFirstSelectedOption().getText().equals(strBCard))) {
					secBCardSlot.sendKeys(strBCard);
				}

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[10]/select")));
				/* Set values for Section BPort */
				WebElement sZport = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[10]/select"));
				Select sZDropdown = new Select(sZport);
				
				String strBPort = oPath.getlObjSection().get(idragCnt).getStrPort_B();
				if(!(sZDropdown.getFirstSelectedOption().getText().equals(strBPort))) {
					sZport.sendKeys(strBPort);
				}
				
				if(oPath.getStrPathMgmt().equals("L1")) {
					
					/* Set value for Section B Channel */
					WebElement sBCh = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[11]/select"));
					Select sBChDrpdwn = new Select(sBCh);
					
					String strBCh = oPath.getlObjSection().get(idragCnt).getStrChannel_B();
					if(!(sBChDrpdwn.getFirstSelectedOption().getText().equals(strBCh))) {
						sBCh.sendKeys(strBCh);
					}
					
					/* Scroll to show the Port Name control */
					JavascriptExecutor jsPortView = (JavascriptExecutor) driver;
					WebElement sPortName = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div[5]/div[5]/div/div[2]/div[2]/form/div/div[3]/div[3]/div/table/tbody/tr[2]/td[12]/input"));
					jsPortView.executeScript("arguments[0].scrollIntoView();", sPortName);
					
					sPortName.sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END), oPath.getlObjSection().get(idragCnt).getStrPortName_B());
				}
				
				idragCnt++;
			}
			
			
			/* Click Z-End */
			WebElement z_End = driver.findElement(By.id(str_ZNE_id));
			WebElement clickZEnd = wait.until(ExpectedConditions.visibilityOf(z_End));
			Actions act_zEnd = new Actions(driver);
			act_zEnd.moveToElement(clickZEnd);
			act_zEnd.click(clickZEnd).build().perform();

			/* Scroll down to show the web controls */
			JavascriptExecutor js2 = (JavascriptExecutor) driver;
			js2.executeScript("scroll(0, 250);");
			js2.executeScript("setTimeout(10);");
				
			if (oPath.getStrPathMgmt().equals("L2")) {
				
				/* Set values for Z-End Card/Slot */
				WebElement zEndCardSlot = driver.findElement(By.id("1_cardSlotId"));
				Select zEndCardSlotDrpdwn= new Select(zEndCardSlot); 
				String strZCardSlot = oPath.getObjEndNE_Z().getStrCardSlot(); 
				if(!(zEndCardSlotDrpdwn.getFirstSelectedOption().getText().equals(strZCardSlot))) {
					zEndCardSlot.sendKeys(strZCardSlot);
				}
				
				/* Set values for Z-End Port */
				WebElement zEndPort = driver.findElement(By.id("1_portNo"));
				Select zEndDropdown = new Select(zEndPort);
				
				String strZPort = oPath.getObjEndNE_Z().getStrPort();
				if(!(zEndDropdown.getFirstSelectedOption().getText().equals(strZPort))) {
					zEndPort.sendKeys(strZPort);
				}
				
				/* Set values for Z-End VLAN Port Type */
				WebElement zEndVLNPortType = driver.findElement(By.id("1_vlanPortType"));
				Select zEndVLNPortTypeDrpDwn= new Select(zEndVLNPortType); 
				String strVLNPortType = oPath.getObjEndNE_Z().getStrVLANPortType();
				if(!(zEndVLNPortTypeDrpDwn.getFirstSelectedOption().getText().equals(strVLNPortType))) {
					zEndVLNPortType.sendKeys(strVLNPortType);
				}
			}
			
			/* Extra processing for Section Registration -- END */
			
			String strFinId = "";
			
			if (oPath.getStrPathMgmt().equals("L2")) {
				strFinId = "btnFinishl2Reg";
			}
			else {
				strFinId = "btnFinishL1Reg";
			}
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(strFinId)));
			
			/* Click Finish Button */
			WebElement finish = driver.findElement(By.id(strFinId));
			WebElement clickFinish = wait.until(ExpectedConditions.visibilityOf(finish));
			Actions act_Fin = new Actions(driver);
			act_Fin.moveToElement(clickFinish);
			act_Fin.click(clickFinish).build().perform();

			//wait.until(ExpectedConditions.presenceOfElementLocated(By.name("ok_button")));
			
			/* Click OK */
			WebElement ok = driver.findElement(By.name("ok_button"));
			WebElement clickOk = wait.until(ExpectedConditions.visibilityOf(ok));
			Actions act_OK = new Actions(driver);
			act_OK.pause(Duration.ofSeconds(2));
			act_OK.moveToElement(clickOk);
			act_OK.click(clickOk).build().perform();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.name("activate_button")));
			
			/* Click Activate */
			WebElement activate = driver.findElement(By.name("activate_button"));
			WebElement clickActivate = wait.until(ExpectedConditions.visibilityOf(activate));
			Actions act_Activ = new Actions(driver);
			act_Activ.pause(Duration.ofSeconds(2));
			act_Activ.moveToElement(clickActivate);
			act_Activ.click(clickActivate).build().perform();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.name("ok_button")));
			
			/* Click OK --> NE setting succeeded */
			WebElement success = driver.findElement(By.name("ok_button"));
			WebElement clickSuccess = wait.until(ExpectedConditions.visibilityOf(success));
			Actions act_Success = new Actions(driver);
			act_Success.pause(Duration.ofSeconds(2));
			act_Success.moveToElement(clickSuccess);
			act_Success.click(clickSuccess).build().perform();
			
		}
		else {
			System.out.println("Path Info is null.");
		}
		
		System.out.println("CreatePath method ENDS.....");
	}
	
	/**
	 * 
	 * @param driver
	 * @param strName
	 * @return
	 */
	public String retrieveNEID(WebDriver driver, String strName) {
		String strID = "";
		String strNE = "<div>" + strName +"</div>";

		System.out.println("Retrieve NED ID START ....");
		
		this.webElement = driver.findElements(By.xpath("//*[@class='ui-draggable ui-droppable']//*"));
		
   		for (WebElement element : webElement) {
   			
   			if( (element.getAttribute("class") != null) &&
   				(element.getAttribute("class").equals("neIcon-20 ne-element ui-droppable ui-draggable ui-draggable-disabled ui-state-disabled"))) {
   				
   				if( element.getAttribute("data-original-title").contains(strNE) ){
   					strID = element.getAttribute("id");
   				}
   			}
   		}		
		
   		System.out.println("Retrieve NED ID END ....");
		return strID;
	}
	
	/**
	 * 
	 * @param strANE
	 * @param strZNE
	 * @param lMidNEIDs
	 * @return
	 */
    public List<String> constructDragIDList(String strANE, String strZNE, List<String> lMidNEIDs) {
		
    	System.out.println("Construct Drag ID List START ....");
    	
		String strDrag = "drag-";
		List<String> lStrDragList = new ArrayList<String>();
		
		String strLeft = strANE.substring(10);
		
		for(String strNE : lMidNEIDs) {
			strDrag = "drag-";
			strDrag += strLeft;
			strDrag += "-";
			strDrag += strNE.substring(10);
			
			lStrDragList.add(strDrag);
			
			strLeft = strNE.substring(10);
		}

		strDrag = "drag-";
		strDrag += strLeft;
		strDrag += "-";
		strDrag += strZNE.substring(10);
		
		lStrDragList.add(strDrag);
		
		System.out.println("Construct Drag ID List END ....");
		
		return lStrDragList;
	}


    /**
     * 
     * @param driver
     * @param wait
     * @param strDel
     * @throws InterruptedException
     */
	public void deletePath(WebDriver driver, WebDriverWait wait, List<String> strDel, String strType) throws InterruptedException {
		
		System.out.println("Delete Path Procedure STARTS.....");
		
		int countDel = 0;
		
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/a")));
		
		//Select Path Menu
		WebElement path = driver.findElement(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/a"));
		WebElement clickPath = wait.until(ExpectedConditions.visibilityOf(path));
		Actions action1 = new Actions(driver);
		action1.pause(Duration.ofSeconds(2));
		action1.click(clickPath).build().perform();	
		
		System.out.println("Delete Path Menu");
		
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/ul/li[1]/a")));
		
		//Select Path List Menu
		WebElement pathList = driver.findElement(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/ul/li[1]/a"));
		WebElement clickPathList = wait.until(ExpectedConditions.visibilityOf(pathList));
		Actions action2 = new Actions(driver);
		action2.moveToElement(clickPathList);
		action2.click(clickPathList).build().perform();
		
		String mwh = driver.getWindowHandle();
		
		System.out.println("Delete Path List Menu");
		
		if (strType.equals("L2")) {

			/*Select L2 Path List Menu */
			WebElement L2pathList = driver.findElement(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/ul/li[1]/ul/li[2]/a"));
			WebElement clickL2PathList = wait.until(ExpectedConditions.visibilityOf(L2pathList));
			Actions action3 = new Actions(driver);
			action3.moveToElement(clickL2PathList);
			action3.click(clickL2PathList).build().perform();			
		}
		else {
			
			/*Select L1 Path List Menu */
			WebElement L1pathList = driver.findElement(By.xpath("/html/body/div[1]/nav/div/div/ul/li[3]/ul/li[1]/ul/li[1]/a"));
			WebElement clickL1PathList = wait.until(ExpectedConditions.visibilityOf(L1pathList));
			Actions action3 = new Actions(driver);
			action3.moveToElement(clickL1PathList);
			action3.click(clickL1PathList).build().perform();
		}
 
		
		Set<String> s=driver.getWindowHandles(); //this method will gives you the handles of all opened windows

		Iterator<String> ite=s.iterator();

		while(ite.hasNext())
		{
		    String popupHandle = ite.next().toString();
		    
		    if(!popupHandle.contains(mwh))
		    {
		        driver.switchTo().window(popupHandle);
		        driver.manage().window().maximize();		        
		        break;
		    }
		}
		
		System.out.println("After maximize...");
		
        List<WebElement> webElement = driver.findElements(By.xpath("//*[@class='ui-widget-content jqgrow ui-row-ltr']//*"));
        String attrName = "";
        
        if(strType.equals("L2")) {
        	attrName = "tblL2List_pathName";
        }
        else {
        	attrName = "tblL1List_pathName";
        }
		
        for (String pathname : strDel) {
        	
	   		for (WebElement element : webElement) {
	   			
	   			if( (element.getAttribute("title") != null) &&
	   				(element.getAttribute("title").equals(pathname)) && 
	   				(element.getAttribute("aria-describedby") != null) &&
	   				(element.getAttribute("aria-describedby").equals(attrName))) {
	   				
	   				WebElement clickpath1 = wait.until(ExpectedConditions.visibilityOf(element));
					Actions actionclickpath = new Actions(driver);
					actionclickpath.moveToElement(clickpath1);
					actionclickpath.click(clickpath1).build().perform();
					
					countDel++;
	   				break;
	   			}
	   		}
        }
       
        System.out.println("countDel = " + countDel);
        
		if(countDel > 0) {			
			//Move to the Dropdown    
		   	System.out.println("Click Modify");
			WebElement mod = driver.findElement(By.id("menu-modify"));
			Actions actions = new Actions(driver);
			WebElement dropdown = wait.until(ExpectedConditions.visibilityOf(mod));
			actions.moveToElement(dropdown);
			actions.click(dropdown).build().perform();
	
			//Wait for the Dropdown Item to become available then click it    
			System.out.println("Click Modify - Delete");
			WebElement del = driver.findElement(By.id("menu-modify-delete"));
			WebElement dropdownitem = wait.until(ExpectedConditions.visibilityOf(del));
			actions.moveToElement(dropdownitem);
			actions.click(dropdownitem).build().perform();
			
//			wait.until(ExpectedConditions.presenceOfElementLocated(By.name("yes_button")));
			
		    // Click Yes
			WebElement yes = driver.findElement(By.name("yes_button"));
			WebElement clickyes = wait.until(ExpectedConditions.visibilityOf(yes));
			Actions actionyes = new Actions(driver);
			actionyes.pause(Duration.ofSeconds(3));
			actionyes.click(clickyes).build().perform();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.name("ok_button")));
			
		    // Click OK --> NE setting succeeded
			WebElement ok = driver.findElement(By.name("ok_button"));
			WebElement clickok = wait.until(ExpectedConditions.visibilityOf(ok));
			Actions actionok = new Actions(driver);
			actionok.pause(Duration.ofSeconds(3));
			actionok.click(clickok).build().perform();
			
			
		}
		else {
			// do nothing because there's nothing to delete
			System.out.println("All of the Path Names specified does not exist.\nThere is nothing to delete.");
		}
		
		System.out.println("Delete Path Procedure ENDS.....");
	}
}
