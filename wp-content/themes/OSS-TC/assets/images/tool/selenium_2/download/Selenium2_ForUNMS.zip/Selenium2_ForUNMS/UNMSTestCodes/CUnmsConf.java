/*****************************************************************************
 * Copyright 2017 NEC Telecom Software Phils., Inc.
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  
 ****************************************************************************/

package testPackage;

public class CUnmsConf {
	
	private String strWebDriver;
	private String strIpAdd;
	private String strUser;
	private String strPass;
	
	public CUnmsConf() {
		super();
	}

	public String getStrIpAdd() {
		return strIpAdd;
	}

	public void setStrIpAdd(String strIpAdd) {
		this.strIpAdd = strIpAdd;
	}

	public String getStrUser() {
		return strUser;
	}

	public void setStrUser(String strUser) {
		this.strUser = strUser;
	}

	public String getStrPass() {
		return strPass;
	}

	public void setStrPass(String strPass) {
		this.strPass = strPass;
	}
	
	public String getStrWebDriver() {
		return strWebDriver;
	}

	public void setStrWebDriver(String strwebdriver) {
		this.strWebDriver = strwebdriver;
	}
	
}
