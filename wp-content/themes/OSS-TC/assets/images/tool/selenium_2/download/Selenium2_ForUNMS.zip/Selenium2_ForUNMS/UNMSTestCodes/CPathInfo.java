/*****************************************************************************
 * Copyright 2017 NEC Telecom Software Phils., Inc.
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  
 ****************************************************************************/

package testPackage;

import java.util.List;

public class CPathInfo {

	/**
	 * Path Management L1 or L2
	 * */
	private String strPathMgmt;
	
	/**
	 * L2 Path Type  802.1Q or 802.1ad
	 */
	private String strPathType;
	
	/**
	 * L1 or L2 Path Name
	 */
	private String strPathName;
	
	/**
	 * VLAN Name
	 */
	private String strVLANName;
	
	/**
	 * VLAN ID
	 */
	private String strVLANID;
	
	/**
	 * Service Type E-Line, E-LAN, or E-Tree
	 */
	private String strSvcType;
	
	/**
	 * A-End NE
	 */
	private CNEInfo objEndNE_A;
	
	/**
	 * Middle NEs
	 */
	private List<String> lStrMidNE;
	
	private List<CSectionInfo> lObjSection;
	
	/**
	 * Z-End NE
	 */
	private CNEInfo objEndNE_Z;
	
	public CPathInfo() {
		
		this.strPathMgmt = null;
		this.strPathType = null;
		this.strPathName = null;
		this.strVLANName = null;
		this.strVLANID = null;
		this.strSvcType = null;
		this.objEndNE_A = null;
		this.lStrMidNE = null;
		this.lObjSection = null;
		this.objEndNE_Z = null;
	}

	public String getStrPathMgmt() {
		return strPathMgmt;
	}

	public void setStrPathMgmt(String strPathMgmt) {
		this.strPathMgmt = strPathMgmt;
	}

	public String getStrPathType() {
		return strPathType;
	}

	public void setStrPathType(String strPathType) {
		this.strPathType = strPathType;
	}

	public String getStrPathName() {
		return strPathName;
	}

	public void setStrPathName(String strPathName) {
		this.strPathName = strPathName;
	}

	public String getStrVLANName() {
		return strVLANName;
	}

	public void setStrVLANName(String strVLANName) {
		this.strVLANName = strVLANName;
	}

	public String getStrVLANID() {
		return strVLANID;
	}

	public void setStrVLANID(String strVLANID) {
		this.strVLANID = strVLANID;
	}

	public String getStrSvcType() {
		return strSvcType;
	}

	public void setStrSvcType(String strSvcType) {
		this.strSvcType = strSvcType;
	}

	public CNEInfo getObjEndNE_A() {
		return objEndNE_A;
	}

	public void setObjEndNE_A(CNEInfo objEndNE_A) {
		this.objEndNE_A = objEndNE_A;
	}

	public List<String> getlStrMidNE() {
		return lStrMidNE;
	}

	public void setlStrMidNE(List<String> lStrMidNE) {
		this.lStrMidNE = lStrMidNE;
	}

	public List<CSectionInfo> getlObjSection() {
		return lObjSection;
	}

	public void setlObjSection(List<CSectionInfo> lObjSection) {
		this.lObjSection = lObjSection;
	}

	public CNEInfo getObjEndNE_Z() {
		return objEndNE_Z;
	}

	public void setObjEndNE_Z(CNEInfo objEndNE_Z) {
		this.objEndNE_Z = objEndNE_Z;
	}
	
	
}
