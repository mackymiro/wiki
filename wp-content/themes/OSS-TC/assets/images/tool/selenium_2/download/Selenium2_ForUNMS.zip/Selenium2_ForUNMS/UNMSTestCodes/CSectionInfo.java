/*****************************************************************************
 * Copyright 2017 NEC Telecom Software Phils., Inc.
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  
 ****************************************************************************/

package testPackage;

public class CSectionInfo {

	private String strName;
	private String strCardSlot_A;
	private String strPort_A;
	private String strChannel_A;
	private String strPortName_A;
	private String strCardSlot_B;
	private String strPort_B;
	private String strChannel_B;
	private String strPortName_B;	
	
	public CSectionInfo() {
		super();
		this.strName = null;
		this.strCardSlot_A = null;
		this.strPort_A = null;
		this.strChannel_A = null;
		this.strPortName_A = null;
		this.strCardSlot_B = null;
		this.strPort_B = null;
		this.strChannel_B = null;
		this.strPortName_B = null;
	}
	
	public CSectionInfo(String strName, String strCardSlot_A, String strPort_A, String strChannel_A, String strPortName_A, 
			                            String strCardSlot_B, String strPort_B, String strChannel_B, String strPortName_B) {
		super();
		this.strName = strName;
		this.strCardSlot_A = strCardSlot_A;
		this.strPort_A = strPort_A;
		this.strChannel_A = strChannel_A;
		this.strPortName_A = strPortName_A;
		this.strCardSlot_B = strCardSlot_B;
		this.strPort_B = strPort_B;
		this.strChannel_B = strChannel_B;
		this.strPortName_B = strPortName_B;
	}

	public String getStrName() {
		return strName;
	}

	public void setStrName(String strName) {
		this.strName = strName;
	}

	public String getStrCardSlot_A() {
		return strCardSlot_A;
	}

	public void setStrCardSlot_A(String strCardSlot_A) {
		this.strCardSlot_A = strCardSlot_A;
	}

	public String getStrPort_A() {
		return strPort_A;
	}

	public void setStrPort_A(String strPort_A) {
		this.strPort_A = strPort_A;
	}

	public String getStrChannel_A() {
		return strChannel_A;
	}
	
	public void setStrChannel_A(String strChannel_A) {
		this.strChannel_A = strChannel_A;
	}
	
	public String getStrPortName_A() {
		return strPortName_A;
	}
	
	public void setStrPortName_A(String strPortName_A) {
		this.strPortName_A = strPortName_A;
	}
	
	public String getStrCardSlot_B() {
		return strCardSlot_B;
	}

	public void setStrCardSlot_B(String strCardSlot_B) {
		this.strCardSlot_B = strCardSlot_B;
	}

	public String getStrPort_B() {
		return strPort_B;
	}

	public void setStrPort_B(String strPort_B) {
		this.strPort_B = strPort_B;
	}
	
	public String getStrChannel_B() {
		return strChannel_B;
	}
	
	public void setStrChannel_B(String strChannel_B) {
		this.strChannel_B = strChannel_B;
	}
	
	public String getStrPortName_B() {
		return strPortName_B;
	}
	
	public void setStrPortName_B(String strPortName_B) {
		this.strPortName_B = strPortName_B;
	}
}
