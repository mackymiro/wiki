A simple, customisable table audit system for PostgreSQL implemented using
triggers.

See:

http://wiki.postgresql.org/wiki/Audit_trigger_91plus
